package com.rytik.myfirstapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        val storage = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val email = storage.getString("email", "def")
        val pass = storage.getString("pass", "def")
        val auto = storage.getBoolean("auto", false)
        if ((email=="def") || (pass=="def")) {
            val intent = Intent (this, RegisterActivity::class.java)
            startActivity(intent)
        }
        if ((email != "def") && (pass != "def") && !auto){
            val intent2 = Intent(this, LoginActivity::class.java)
            startActivity(intent2)
        }
        if ((email != "def") && (pass != "def") && auto){
            val intent2 = Intent(this, ContentActivity::class.java)
            startActivity(intent2)
        }
    }
}